package com.codepath.instagram.helpers;

public class Constants {
    public static final String REDIRECT_URI = "oauth://codepath.com";
    public static final String SCOPE = "basic";
}
